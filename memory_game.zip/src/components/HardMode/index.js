import React from 'react';
import Board from '../Board';

const HardMode = () => {
  return <Board difficultyVal={5} />;
};

export default HardMode;
