import React from 'react';
import Board from '../Board/index';

const EasyMode = () => {
  return <Board difficultyVal={3} />;
};

export default EasyMode;
