import React from 'react';
import Board from '../Board/index';

const MediumMode = () => {
  return <Board difficultyVal={4} />;
};

export default MediumMode;
